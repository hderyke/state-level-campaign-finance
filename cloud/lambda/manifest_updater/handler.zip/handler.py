"""
lambda/manifest_updater/handler.py

Triggered by S3 PutObject on metadata/successful/*/manifest.json.
Reads every successful state manifest, rebuilds metadata/manifest.csv.
"""

import boto3
import csv
import io
import json

s3 = boto3.client("s3")


def handler(event, context):
    bucket = event["Records"][0]["s3"]["bucket"]["name"]

    # List all successful state manifests
    paginator = s3.get_paginator("list_objects_v2")
    rows = {}

    for page in paginator.paginate(Bucket=bucket, Prefix="metadata/successful/"):
        for obj in page.get("Contents", []):
            key = obj["Key"]
            if not key.endswith("/manifest.json"):
                continue
            # key shape: metadata/successful/{State}/manifest.json
            parts = key.split("/")
            if len(parts) != 4:
                continue
            try:
                resp = s3.get_object(Bucket=bucket, Key=key)
                manifest = json.loads(resp["Body"].read())
                state = manifest.get("state")
                last_synced = (manifest.get("last_updated") or "")[:10]  # YYYY-MM-DD
                if state and last_synced:
                    rows[state] = last_synced
            except Exception as e:
                print(f"[warn] could not read {key}: {e}")

    # Write master manifest.csv
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["state", "last_synced"])
    for state in sorted(rows):
        writer.writerow([state, rows[state]])

    s3.put_object(
        Bucket=bucket,
        Key="metadata/manifest.csv",
        Body=buf.getvalue().encode("utf-8"),
        ContentType="text/csv",
    )

    print(f"manifest.csv updated — {len(rows)} state(s): {sorted(rows)}")
    return {"statusCode": 200, "states": len(rows)}
